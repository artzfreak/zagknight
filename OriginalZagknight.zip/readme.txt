Instructions

Custom Knight: The ZagKnight folder goes into your Custom Knight > Skins folder.

Custom Audio: The contents of the Custom Audio folder go in the Replace Audio folder in the Custom Audio mod.

Transcendence: The Transcendence folder has modified Transcendence charms to match the diamond style of the ZagKnight charms. The contents of this folder can be used to replace the .pngs in the Transcendence mod folder. You’ll have to manually swap back to the vanilla charms when using a different skin. Credit to Pimpas for the original Transcendence mod and to Tsira for the original Transcendence charm art. 

Change Log

2023-02-23 - Vespa’s Vengeance added to Transcendence charms

2023-02-04 - updated HUD sprite sheet to include Steel Soul frame recolor

2022-10-04 - added Death sound to Custom Audio

2022-10-03 - added scene swap for Room_shop, Ruins1_05b

2022-10-01 - updated HUD sprite sheet to tweak Godhome Health Cap

2022-09-30 - fixed Webbed animation to account for the fact that 99% of the time, Zag will be facing right before sitting on trap bench

2022-09-29 - added Transcendence charms

2022-09-15 - added Kingsoul/Voidheart cutscene swap (thought it doesn’t appear to be working)

2022-07-12 - updated scene swap for Room_Nailmaster, added scene swap for Ruins2_03b, added global geo rock swaps

2022-07-06 - added scene swaps for Room_nailmaster, Ruins_House_01, and Ruins2_03b

2022-07-03 - updated HUD.png

2022-06-30 - fixed typo in Menderbug swap text; updated Compass.png

2022-06-28 - Published

Known Issues

2022-10-01 - Update on preloads: Custom Knight does not preload global swaps. It only loads the sprite sheet when you enter a room that would have that item in vanilla. So, for geo rock swaps, in a rando, some geo rocks will appear vanilla until you enter a room that is a vanilla location for that kind of geo rock, at which point Custom Knight will load the sprite sheet and you will see the swapped version. On Macs, it appears that once the new version of the sprite sheet is loaded, it will persist across saves and game sessions.

2022-07-12 - When first applying the ZagKnight skin for a rando, the 420 rock swap will not load properly. In order to fix this, you must enter the vanilla location of the 420 rock, which will force the game to load the hash and apply the swap. Once you have done this, the 420 rock will load properly wherever you find it. Not confirmed yet, but I’m pretty sure this will hold true across saves. So you can debug yourself to the 420 rock room, and then start a new save. It’s possible this fix will hold even if you apply a different skin and then return to ZagKnight (but probably not if you enter the 420 rock room while the new skin is applied). Unsure if this fix will work across save slots, or only on the save slot that accesses the 420 rock room.
